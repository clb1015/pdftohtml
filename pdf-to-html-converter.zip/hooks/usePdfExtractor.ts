
import { useState, useCallback } from 'react';
import '../types'; // This ensures the pdfjsLib declaration is included

export const usePdfExtractor = () => {
  const [extractedText, setExtractedText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const extractPdfText = useCallback(async (file: File): Promise<string | null> => {
    setIsLoading(true);
    setError('');
    setExtractedText('');

    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = async (event) => {
            if (!event.target?.result) {
                setError('Failed to read file.');
                setIsLoading(false);
                reject(new Error('Failed to read file.'));
                return;
            }

            try {
                const typedArray = new Uint8Array(event.target.result as ArrayBuffer);
                const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;
                const numPages = pdf.numPages;
                let fullText = '';

                for (let i = 1; i <= numPages; i++) {
                    const page = await pdf.getPage(i);
                    const textContent = await page.getTextContent();
                    const pageText = textContent.items.map((item: any) => item.str).join(' ');
                    fullText += pageText + '\n\n';
                }
                
                setExtractedText(fullText);
                setIsLoading(false);
                resolve(fullText);
            } catch (e) {
                console.error('Error parsing PDF:', e);
                const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred while parsing the PDF.';
                setError(errorMessage);
                setIsLoading(false);
                reject(new Error(errorMessage));
            }
        };

        reader.onerror = () => {
            setError('Error reading file.');
            setIsLoading(false);
            reject(new Error('Error reading file.'));
        };

        reader.readAsArrayBuffer(file);
    });
  }, []);

  return { extractedText, extractPdfText, isLoading, error };
};
