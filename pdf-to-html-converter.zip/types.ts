
// This declaration allows TypeScript to recognize the pdfjsLib object
// loaded from the CDN script in index.html.
declare const pdfjsLib: any;
