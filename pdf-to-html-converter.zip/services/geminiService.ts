
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const convertTextToHtml = async (pdfText: string): Promise<string> => {
  const prompt = `
    You are an expert web developer. Your task is to convert the following raw text, which was extracted from a PDF document, into a single, well-structured, and aesthetically pleasing HTML document. 
    - Use semantic HTML5 tags like <header>, <nav>, <main>, <article>, <section>, <aside>, and <footer> where appropriate.
    - Structure the content with headings (<h1> to <h6>), paragraphs (<p>), lists (<ul>, <ol>, <li>), and tables (<table>).
    - Preserve the original meaning and structure of the text.
    - Ensure the HTML is well-formed.
    - The output must be ONLY the complete HTML code, starting with <!DOCTYPE html> and ending with </html>. 
    - Do not include any explanatory text, markdown syntax like \`\`\`html, or comments outside of the HTML code itself.

    Here is the text to convert:
    ---
    ${pdfText}
    ---
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
    });
    
    // The response.text is expected to be a clean HTML string based on the prompt.
    let htmlOutput = response.text.trim();

    // Clean up potential markdown code fences, just in case
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = htmlOutput.match(fenceRegex);
    if (match && match[2]) {
      htmlOutput = match[2].trim();
    }
    
    // Ensure it starts with a doctype
    if (!htmlOutput.toLowerCase().startsWith('<!doctype html>')) {
      // If the model forgot the doctype, add it.
      if (htmlOutput.toLowerCase().startsWith('<html>')) {
          htmlOutput = '<!DOCTYPE html>\n' + htmlOutput;
      } else {
        // If it's just a fragment, wrap it in a full document structure
        htmlOutput = `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Converted Document</title>\n  <style>body { font-family: sans-serif; line-height: 1.6; padding: 20px; } table { border-collapse: collapse; width: 100%; } th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }</style>\n</head>\n<body>\n${htmlOutput}\n</body>\n</html>`;
      }
    }

    return htmlOutput;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to generate HTML from the AI model.");
  }
};
