
import React, { useState, useCallback } from 'react';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

interface ResultItemProps {
  htmlContent: string;
}

type Tab = 'preview' | 'code';

const ResultItem: React.FC<ResultItemProps> = ({ htmlContent }) => {
  const [activeTab, setActiveTab] = useState<Tab>('preview');
  const [hasCopied, setHasCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(htmlContent).then(() => {
      setHasCopied(true);
      setTimeout(() => setHasCopied(false), 2000);
    });
  }, [htmlContent]);

  const TabButton: React.FC<{ tab: Tab; label: string }> = ({ tab, label }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
        activeTab === tab
          ? 'bg-sky-600 text-white'
          : 'text-slate-300 hover:bg-slate-700'
      }`}
    >
      {label}
    </button>
  );

  return (
    <>
      <div className="flex items-center justify-between p-3 bg-slate-800 border-b border-slate-700">
        <div className="flex space-x-2">
          <TabButton tab="preview" label="Preview" />
          <TabButton tab="code" label="HTML Code" />
        </div>
        {activeTab === 'code' && (
          <button
            onClick={handleCopy}
            className="flex items-center gap-2 px-3 py-1.5 text-sm bg-slate-600 hover:bg-slate-500 rounded-md transition-colors"
          >
            <ClipboardIcon />
            {hasCopied ? 'Copied!' : 'Copy'}
          </button>
        )}
      </div>
      <div className="p-1">
        {activeTab === 'preview' && (
          <iframe
            srcDoc={htmlContent}
            title="HTML Preview"
            sandbox="allow-same-origin"
            className="w-full h-[60vh] bg-white rounded-lg border-none"
          />
        )}
        {activeTab === 'code' && (
          <pre className="w-full h-[60vh] overflow-auto p-4 bg-slate-900 rounded-lg">
            <code className="text-sm text-slate-300 whitespace-pre-wrap">
              {htmlContent}
            </code>
          </pre>
        )}
      </div>
    </>
  );
}

interface ResultDisplayProps {
  results: { fileName: string; htmlContent: string; }[];
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ results }) => {
  const [activeIndex, setActiveIndex] = useState<number | null>(results.length > 0 ? 0 : null);

  const handleToggle = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  if (results.length === 0) {
    return null;
  }

  if (results.length === 1) {
    return (
      <div className="bg-slate-800/50 rounded-2xl shadow-lg border border-slate-700 overflow-hidden">
        <ResultItem htmlContent={results[0].htmlContent} />
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <h2 className="text-xl font-bold text-slate-200 pl-1">Conversion Results</h2>
      {results.map((result, index) => (
        <div key={result.fileName} className="bg-slate-800/50 rounded-xl shadow-lg border border-slate-700 overflow-hidden transition-all">
          <button
            onClick={() => handleToggle(index)}
            className="w-full flex justify-between items-center p-4 text-left font-medium text-slate-200 hover:bg-slate-800"
          >
            <span>{result.fileName}</span>
            <ChevronDownIcon className={`w-5 h-5 transition-transform ${activeIndex === index ? 'rotate-180' : ''}`} />
          </button>
          {activeIndex === index && (
            <div className="border-t border-slate-700">
              <ResultItem htmlContent={result.htmlContent} />
            </div>
          )}
        </div>
      ))}
    </div>
  );
};
